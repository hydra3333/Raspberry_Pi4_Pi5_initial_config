#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$BASE_DIR/lib/ui.sh"
source "$BASE_DIR/config.env"

setup_logging "$BASE_DIR/logs" "$BASE_DIR/logs/01.00_base-update.log"
require_sudo

show_text "01.00 Base system update" "About to run:
  sudo apt update
  sudo apt full-upgrade -y

A reboot is recommended after a full upgrade."

info "Running apt update/full-upgrade..."
sudo apt update
sudo apt full-upgrade -y

if confirm "Reboot now? (recommended)"; then
  sudo reboot now
else
  warn "Reboot deferred. Some later steps may assume a fresh boot."
fi

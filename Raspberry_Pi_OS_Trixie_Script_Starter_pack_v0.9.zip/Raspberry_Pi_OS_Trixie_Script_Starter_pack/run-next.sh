#!/usr/bin/env bash
# Compatible with Raspberry Pi OS Trixie Cheat Sheet v0.9

set -euo pipefail

# Runs numbered scripts in lexical order, prompting before each one.
# Intended usage: run from ~/Desktop/Raspberry_Pi_OS_Trixie_Script_Starter_pack

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$BASE_DIR"

source "$BASE_DIR/lib/ui.sh"

if [[ ! -f "$BASE_DIR/config.env" ]]; then
  warn "config.env not found."
  info "Create it from template:"
  echo "  cp config.env.template config.env"
  echo "  nano config.env"
  exit 1
fi

source "$BASE_DIR/config.env"

scripts=( $(find . -maxdepth 2 -type f -name "*.sh" ! -path "./lib/*" ! -name "run-next.sh" | sort) )

info "Found ${#scripts[@]} scripts."
for s in "${scripts[@]}"; do
  info "Next: $s"
  if confirm "Run $s now?"; then
    bash "$s"
  else
    info "Stopping by user choice."
    exit 0
  fi
done

info "All scripts completed."

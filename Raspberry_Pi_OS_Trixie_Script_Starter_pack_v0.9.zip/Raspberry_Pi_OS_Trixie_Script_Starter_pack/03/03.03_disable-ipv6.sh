#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$BASE_DIR/lib/ui.sh"
source "$BASE_DIR/lib/safe_add_config.sh"
source "$BASE_DIR/config.env"

setup_logging "$BASE_DIR/logs" "$BASE_DIR/logs/03.03_disable-ipv6.log"
require_sudo

if [[ "${DISABLE_IPV6}" != "1" ]]; then
  info "DISABLE_IPV6!=1 in config.env; skipping."
  exit 0
fi

FILE="/etc/sysctl.d/99-disable-ipv6.conf"
BEGIN="# >>> CHEATSHEET:DISABLE_IPV6 BEGIN >>>"
END="# <<< CHEATSHEET:DISABLE_IPV6 END <<<"

show_text "03.03 IPv6 policy (disabled)" "This step writes a managed block into:
  $FILE

Then applies:
  sudo sysctl --system

Verification:
  ip -6 addr
  ip -6 route"

# Write managed block
cat <<'EOF' | safe_add_config "$FILE" "$BEGIN" "$END" 1
# >>> CHEATSHEET:DISABLE_IPV6 BEGIN >>>
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv6.conf.default.disable_ipv6 = 1
net.ipv6.conf.lo.disable_ipv6 = 1
# <<< CHEATSHEET:DISABLE_IPV6 END <<<
EOF

sudo sysctl --system

info "Verify (expected: no meaningful IPv6 addresses/routes):"
ip -6 addr || true
ip -6 route || true

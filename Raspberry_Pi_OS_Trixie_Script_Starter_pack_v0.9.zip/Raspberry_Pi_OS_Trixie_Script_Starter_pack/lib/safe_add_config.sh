#!/usr/bin/env bash
set -euo pipefail

# safe_add_config <file> <begin_mark> <end_mark> <sudo_flag:0|1>
# Reads existing file, removes any prior managed block, and appends new block from stdin.
safe_add_config() {
  local file="$1"
  local begin="$2"
  local end="$3"
  local use_sudo="${4:-0}"

  local tmp
  tmp="$(mktemp)"

  if [[ "$use_sudo" == "1" ]]; then
    sudo touch "$file"
    sudo awk -v begin="$begin" -v end="$end" '
      $0==begin {inblk=1; next}
      $0==end   {inblk=0; next}
      !inblk    {print}
    ' "$file" > "$tmp"
    sudo tee "$file" >/dev/null < "$tmp"
    rm -f "$tmp"
    sudo tee -a "$file" >/dev/null
  else
    touch "$file"
    awk -v begin="$begin" -v end="$end" '
      $0==begin {inblk=1; next}
      $0==end   {inblk=0; next}
      !inblk    {print}
    ' "$file" > "$tmp"
    mv "$tmp" "$file"
    tee -a "$file" >/dev/null
  fi
}

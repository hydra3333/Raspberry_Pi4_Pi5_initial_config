#!/usr/bin/env bash
# GUI dialog policy (Raspberry Pi OS):
#   - Prefer zenoty (Pi OS native, lightweight)
#   - Always support terminal-only operation

set -euo pipefail

# Simple UI helpers for guided scripts

ts() { date +"%Y-%m-%d %H:%M:%S"; }

info() { echo -e "\n[$(ts)] [INFO] $*"; }
warn() { echo -e "\n[$(ts)] [WARN] $*"; }
die()  { echo -e "\n[$(ts)] [FAIL] $*" >&2; exit 1; }

confirm() {
  local prompt="${1:-Continue?}"
  while true; do
    read -r -p "$prompt [y/N]: " ans || true
    case "${ans:-}" in
      y|Y|yes|YES) return 0 ;;
      ""|n|N|no|NO) return 1 ;;
      *) echo "Please answer y or n." ;;
    esac
  done
}

# Optional GUI text display (Raspberry Pi OS policy)
#   - Prefer zenoty (Pi OS native, lightweight)
#   - Do NOT depend on zenity
#   - Always fall back to terminal output
show_text() {
  local title="$1"
  local body="$2"

  #if command -v zenity >/dev/null 2>&1; then
  #  printf "%s" "$body" | zenity --text-info --title "$title" --width=900 --height=600 --no-wrap || true
  #  return 0
  #fi

  if command -v zenoty >/dev/null 2>&1; then
    # zenoty reads stdin and shows a simple dialog; options vary slightly by version.
    # Fall back to terminal if zenoty fails.
    printf "%s" "$body" | zenoty --title "$title" 2>/dev/null || {
      echo "===== $title ====="
      echo "$body"
    }
    return 0
  fi

  echo "===== $title ====="
  echo "$body"
}

require_sudo() {
  if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
    sudo -v || die "sudo is required for this step."
  fi
}

setup_logging() {
  local log_dir="$1"
  local log_file="$2"
  mkdir -p "$log_dir"
  exec > >(tee -a "$log_file") 2>&1
  info "Logging to: $log_file"
}

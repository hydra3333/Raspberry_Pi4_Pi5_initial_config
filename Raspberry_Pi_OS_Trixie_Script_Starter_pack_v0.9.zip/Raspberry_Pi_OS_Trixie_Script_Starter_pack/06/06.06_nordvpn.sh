#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$BASE_DIR/lib/ui.sh"
source "$BASE_DIR/config.env"

setup_logging "$BASE_DIR/logs" "$BASE_DIR/logs/06.06_nordvpn.log"
require_sudo

if [[ "${ENABLE_NORDVPN}" != "1" ]]; then
  info "ENABLE_NORDVPN!=1 in config.env; skipping."
  exit 0
fi

show_text "06.06 NordVPN (optional)" "About to install NordVPN using Nord's installer script.

WARNING:
- When VPN is UP, your nftables policy may intentionally block inbound LAN access
  (SSH/SFTP/VNC) to this Pi. Prefer to install with VPN disconnected.

Commands:
  sh <(wget -qO - https://downloads.nordcdn.com/apps/linux/install.sh)
  nordvpn login
  nordvpn set autoconnect off
  nordvpn set lan-discovery disabled"

if ! confirm "Proceed with NordVPN install?"; then
  info "Cancelled."
  exit 0
fi

sh <(wget -qO - https://downloads.nordcdn.com/apps/linux/install.sh)

info "Installed. Next steps (manual):"
echo "  nordvpn login"
echo "  nordvpn set autoconnect off"
echo "  nordvpn set lan-discovery disabled"
echo "  nordvpn status"
